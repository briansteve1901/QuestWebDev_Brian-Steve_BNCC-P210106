const firebaseConfig = {
    apiKey: "AIzaSyDsR_ZURUuCjTl1G5htQi7Zefz4GlWPwCk",
    authDomain: "bncc-elite-team.firebaseapp.com",
    projectId: "bncc-elite-team",
    storageBucket: "bncc-elite-team.appspot.com",
    messagingSenderId: "279735815975",
    appId: "1:279735815975:web:ab3d02a4a0562ee23ea302",
    measurementId: "G-LJLS4Q59QC"
};

firebase.initializeApp(firebaseConfig);
var firestore=firebase.firestore();


const submitBtn=document.querySelector('#Submit');

let userName=document.querySelector('#userFullName');
let userEmail=document.querySelector('#userEmail');
let userPhoneNumber= document.querySelector('#userPhoneNumber');
let userComments=document.querySelector('#userComments');
let error1=document.querySelector('#error_msg1');
let error2=document.querySelector('#error_msg2');
let error3=document.querySelector('#error_msg3');
let error4=document.querySelector('#error_msg4');

const db=firestore.collection("Submitter");

submitBtn.addEventListener('click',function(event){
    event.preventDefault();
    error1.innerText='';
    error2.innerText='';
    error3.innerText='';
    error4.innerText='';
    let userNameInput = userName.value;
    let userEmailInput = userEmail.value;
    let userPhoneNumberInput = userPhoneNumber.value;
    let userCommentsInput = userComments.value;

    if(userNameInput.length==0){
        error1.innerText='Name must be filled';
    }

    else if((!(userEmailInput.includes('@')))||userEmailInput.length==0){
        error2.innerText='Email must be filled and include @';
    }
    
    else if((!(userPhoneNumberInput.startsWith('08')))||
    userPhoneNumberInput.length==0||
    userPhoneNumberInput.length>14){
        error3.innerText='Phone number must be filled, the first digit must be 0, the second digit must be 8, and phone number length is no more than 14 digits';
    }

    else if(userCommentsInput.split(" ").length<5||userCommentsInput.split(" ").length>100){
        error4.innerText='Comment must be in the range of 5 words to 100 words';
    }
    else{
        db.doc().set({
            Name: userNameInput,
            Email:userEmailInput,
            PhoneNumber:userPhoneNumberInput,
            Comments: userCommentsInput
         }).then(function(){
             console.log("Data Submitted");
         });
         $("#userFullName").val("");
         $("#userEmail").val("");
         $("#userPhoneNumber").val("");
         $("#userComments").val("");
         $("#successAlert").removeClass("d-none");
    }
})